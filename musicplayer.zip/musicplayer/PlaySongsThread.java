package com.te.learn.Assessment.musicplayer;

public class PlaySongsThread implements Runnable {

	public PlaySongsThread() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

}
