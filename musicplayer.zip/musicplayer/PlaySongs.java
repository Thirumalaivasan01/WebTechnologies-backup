package com.te.learn.Assessment.musicplayer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.Scanner;

public class PlaySongs implements Runnable {

	public void playAllSongs(ArrayList<MusicFiles> files) {
		System.out.println("Playing...");
		for (MusicFiles musicFiles : files) {
			System.out.println(musicFiles);
			// thread.start();
			// Thread thread1=new Thread(PlaySongs());
		}
	}

	public void playSongsRandomly(ArrayList<MusicFiles> files) {
		// Random random = new Random();
		// int id = random.nextInt(6);
		ArrayList<MusicFiles> arrayList1 = new ArrayList<MusicFiles>(files);
		Collections.shuffle(arrayList1);
		// System.out.println(id);
		System.out.println("Playing...");
		for (MusicFiles musicFiles : arrayList1) {
			System.out.println("Playing...");
			System.out.println(musicFiles);
		}

	}

	public void playParticularSong(ArrayList<MusicFiles> files) {
		for (MusicFiles musicFiles : files) {
			System.out.println(musicFiles);
		}
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the song Id that to be played: ");
		int song = sc.nextInt();
		for (MusicFiles musicFiles : files) {
			if (musicFiles.getSongId() == song) {
				System.out.println("Playing...");
				System.out.println(musicFiles);
			}
		}
	}

	@Override
	public synchronized void run() {
		// TODO Auto-generated method stub

	}

}
