package com.te.learn.Assessment.musicplayer;

import java.util.ArrayList;
import java.util.Scanner;

public class EditSongs extends Home {
	int songId;
	String songTitle;
	String artistName;
	String albumName;
	String songLocation;
	String description;

	public void addSong(ArrayList<MusicFiles> list) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter song Id, Title, ArtistName, AlbumName, SongLocation and Discription");
		songId = sc.nextInt();
		sc.nextLine();
		songTitle = sc.nextLine();
		artistName = sc.nextLine();
		albumName = sc.nextLine();
		songLocation = sc.nextLine();
		description = sc.nextLine();
		list.add(new MusicFiles(songId, songTitle, artistName, albumName, songLocation, description));
		System.out.println("Song added to the PlayList!");
		for (MusicFiles musicFiles : list) {
			System.out.println(musicFiles);
		}
	}

	public void editExistingSong(ArrayList<MusicFiles> list) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the song Id that you want to edit");
		int id = sc.nextInt();
		for(int i=0;i<list.size();i++) {
			if(list.get(i).getSongId()==id) {
				
			}
		}

	}

	public void deleteExistingSong(ArrayList<MusicFiles> list) {

	}

}
